from matplotlib import pyplot as plt
import io
import os
import glob
import cv2
import numpy as np

class imagesearch():
    def __init__(self, queryimage, searchimage, save_path):
        self.queryimage = queryimage
        self.searchimage = searchimage
        self.save_path = save_path
        self.image_file =  os.path.basename(searchimage)
        self.initialize() 
            
    def initialize(self):
        self.order_id = 1

    def search_feature_match(self,queryimage, searchimage):
        img1 = cv2.imread(queryimage,0)         
        img2 = cv2.imread(searchimage,0) 
        sift = cv2.xfeatures2d.SIFT_create()
        kp1, des1 = sift.detectAndCompute(img1,None)
        kp2, des2 = sift.detectAndCompute(img2,None)
        print("No of Key Points", len(kp2))
        FLANN_INDEX_KDTREE = 0
        index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 10)
        search_params = dict(checks=1000)  
        flann = cv2.FlannBasedMatcher(index_params,search_params)
        matches = flann.knnMatch(des1,des2,k=2)


        good = []
        contorurarray = []
        for m,n in matches:
            if m.distance < 0.75*n.distance:
                contorurarray.append([m.distance,n.distance])
                good.append(m)

        print('No.of Good Points',len(good))
        print('No.of Matching points',len(matches))
        
        src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
        dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)
        print('No.of dst_pts',len(dst_pts))
        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)
        matchesMask = mask.ravel().tolist()
        h,w = img1.shape[:2]
        pts = np.float32([ [0,0],[0,h-1],[w-1,h-1],[w-1,0] ]).reshape(-1,1,2)

        dst = cv2.perspectiveTransform(pts,M)
        draw_params = dict(matchColor = (0,255,0), singlePointColor = None,  matchesMask = matchesMask, flags = 2)
        img3 = cv2.polylines(img2, [np.int32(dst)], True, (0,255,0),10, cv2.LINE_AA)
        cv2.imwrite(os.path.join(self.save_path,self.image_file+"search_feature_match.jpg"), img3)

   
    def rectangle_focus(self,queryimage, searchimage):
        print('------Rectangle Focus Initated-----')
        image = cv2.imread(searchimage)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        gray = clahe.apply(gray)
        edge_enh = cv2.Laplacian(gray, ddepth = cv2.CV_8U, 
                                ksize = 3, scale = 1, delta = 0)
        blurred = cv2.bilateralFilter(edge_enh, 13, 50, 50)
        (_, thresh) = cv2.threshold(blurred, 55, 255, cv2.THRESH_BINARY)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        closed = cv2.erode(closed, None, iterations = 4)
        closed = cv2.dilate(closed, None, iterations = 4)
        (_, cnts, _) = cv2.findContours(closed.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        c = sorted(cnts, key = cv2.contourArea, reverse = True)[0]
        rect = cv2.minAreaRect(c)
        box = np.int0(cv2.boxPoints(rect))
        cv2.drawContours(image, [box], -1, (0, 255, 0), 3)
        retval = cv2.imwrite(os.path.join(self.save_path,self.image_file+self.image_file+"rectangle_focus.jpg"), image)

    def detect(self,**kwargs):
        self.search_feature_match(self.queryimage, self.searchimage)
        # self.rectangle_focus(self.queryimage, self.searchimage)

    
# def JiffyBarcode(queryimage, searchimage, save_path):
#     image_barcode_holder = JiffyBarcode(queryimage, searchimage, save_path)   
#     image_barcode_holder.detect()
#     return 
 
if __name__ == "__main__":
    
    # if len(sys.argv) >= 1:
        # source = sys.argv[1]
        
    searchimage =  'C:\\development\\cv2\\search_image\\pan_logo.png' # logo image
    save_path = 'C:\\development\\cv2\\save_folder'

    files = glob.glob('C:\\development\\cv2\\pan_images\\*.jpg', recursive = True) 
    for i in files:
        image_holder = imagesearch(searchimage, i, save_path )
        image_holder.detect()