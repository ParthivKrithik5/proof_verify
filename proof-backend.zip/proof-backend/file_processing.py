import os
import sys
import subprocess
import numpy as np

import cv2
from PIL import Image

# from pdf2image import convert_from_path
# from PyPDF2 import PdfFileMerger, PdfFileReader

# PDF to Single Image Convertion
# def pdf_to_singleImage(input_path, file_name, output_path):
#     print("pdf_to_singleImage : start")
#     try:
#         try:
#             os.mkdir(output_path)
#             print("jj")
#         except:
#             pass
#         try:
#             os.chmod(output_path, 0o777)
#         except Exception as e:
#             print (e)
#         dpi = 0   # dots per inch
#         pages = convert_from_path(input_path+file_name, dpi)
#         for i in range(len(pages)):
#             page = pages[i]
#             # page_array = image_processing(np.array(page))
#             # img = Image.fromarray(page_array)
#             page.save(output_path+'{}.jpg'.format(i+1), 'JPEG') 
            
#     except Exception as e:
#         print("file_processing : pdf_to_singleImage : error : ",e)
#     print("pdf_to_singleImage : end")

def image_processing(image_array):
    try:
        print("image_processing : start")  
        # Load image, grayscale, and Otsu's threshold
        gray = cv2.cvtColor(image_array, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

        # Remove horizontal lines
        horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (50,1))
        detect_horizontal = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel, iterations=2)
        cnts = cv2.findContours(detect_horizontal, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = cnts[0] if len(cnts) == 2 else cnts[1]
        for c in cnts:
            cv2.drawContours(thresh, [c], -1, (0,0,0), 2)

        # Remove vertical lines
        vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1,15))
        detect_vertical = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel, iterations=2)
        cnts = cv2.findContours(detect_vertical, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = cnts[0] if len(cnts) == 2 else cnts[1]
        for c in cnts:
            cv2.drawContours(thresh, [c], -1, (0,0,0), 3)

        result = cv2.bitwise_and(image_array, image_array, mask=thresh)
        result[thresh==0] = (255,255,255)
        
        #Blurring the image
        Gaussian_blurred_1 = np.hstack([cv2.GaussianBlur(result,(3,3),0)]) 

        #sharpening the image
        kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
        im = cv2.filter2D(Gaussian_blurred_1, -1, kernel)
        
    except Exception as e:
        print("image_processing : error : ",e)
    print("image_processing : end") 
    return im
    
# Single Image to Single TXT
def singleImage_to_txt(input_path, output_path):
    print("singleimage_to_txt : start")
    try:
        try:
            os.mkdir(output_path)
        except:
            pass
        try:
            os.chmod(output_path, 0o777)
        except Exception as e:
            print (e)
        for file_name in os.listdir(input_path):
            out_file_name = file_name[:-4]
            
            if not os.path.exists(output_path):
                os.mkdir(output_path)   
            if sys.platform != "win32":
                subprocess.run('tesseract '+input_path+file_name+' '+output_path+out_file_name+'  --psm 6 -c preserve_interword_spaces=1', shell=True)
            else:
                subprocess.run('tesseract '+input_path+file_name+' '+output_path+out_file_name+'  --psm 6 -c preserve_interword_spaces=1', shell=True)
    except Exception as e:
        print("file_processing : singleImage_to_txt : error : ",e)
    print("singleimage_to_txt : end")

def merge_txt(input_path, output_path, file_name):
    print("merge_txt : start")
    try:
        try:
            os.mkdir(output_path)
        except:
            pass
        try:
            os.chmod(output_path, 0o777)
        except Exception as e:
            print (e)
        files_count = len(os.listdir(input_path))    
        filenames = [str(x+1)+'.txt' for x in range(files_count)]
        with open(output_path+ file_name+'.txt', 'w') as outfile:
            for fname in filenames:
                with open(input_path+fname) as infile:
                    for line in infile:
                        outfile.write(line)  
    except Exception as e:
        print("file_processing : merge_txt : error : ",e)
    print("merge_txt : end")    


if __name__ == "__main__":
    page_array = image_processing(np.array("pan1.png"))
    img = Image.fromarray(page_array)
    img.save('image.jpg') 